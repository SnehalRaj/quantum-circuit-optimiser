# Rule library

Priority is an editable judgement. Initial gains retain the evidence scope.

| Rule | Priority | Support | Initial 16-bit division gain | Initial 256-bit division gain | Development trials | Enabling paths |
|:--|--:|:--|--:|--:|--:|--:|
| R01 Direct record and replay | 100 | implemented | 58.832% | 58.965% | 2 | 0 |
| R21 Edit the ordered payload program | 100 | implemented | unknown | unknown | 52 | 0 |
| R02 Measured cleanup | 95 | implemented | 44.279% | 44.920% | 9 | 0 |
| R03 Fuse replay corrections | 90 | proposal | unknown | unknown | 0 | 0 |
| R04 Trim proved zero bits | 85 | implemented | 25.774% | 28.244% | 4 | 0 |
| R05 Split the correction carry ladder | 82 | proposal | unknown | unknown | 0 | 0 |
| R06 Compact scratch wire IDs | 80 | implemented | unknown | unknown | 0 | 0 |
| R07 Reconstruct a retained branch bit | 78 | proposal | unknown | unknown | 0 | 0 |
| R08 Group halvings with Jump-2 | 74 | implemented | 10.371% | 37.713% | 10 | 0 |
| R09 Pack the reachable transcript alphabet | 70 | proposal | unknown | unknown | 0 | 0 |
| R10 Use the ping-pong representation | 66 | implemented | -31.690% | 18.784% | 10 | 0 |
| R11 Group signed updates with Leapfrog | 62 | implemented | -14.243% | 7.255% | 10 | 0 |
| R12 Specialise sparse-modulus arithmetic | 58 | proposal | unknown | unknown | 0 | 0 |
| R13 Route through a shared arithmetic kernel | 54 | proposal | unknown | unknown | 0 | 0 |
| R14 Factor shared Boolean products | 50 | implemented | unknown | unknown | 0 | 0 |
| R15 Cache and reuse a shared AND | 46 | implemented | unknown | unknown | 0 | 0 |
| R16 Reorder commuting gates | 42 | implemented | unknown | unknown | 0 | 0 |
| R17 Cancel inverse gate pairs | 38 | implemented | unknown | unknown | 0 | 0 |
| R18 Reduce the round budget | 34 | implemented | 8.776% | unknown | 0 | 0 |
| R19 Use a fitted width schedule | 30 | implemented | 6.228% | unknown | 4 | 0 |
| R20 Shorten a comparison window | 26 | implemented | 6.851% | unknown | 7 | 0 |

Read scores.json for point-addition and cell evidence, failures, contexts, and qualified audit scores.
The sixteen-bit and full-width division figures stay separate. Proposed rules cannot be applied.
A cell-level gate saving supplies no full-circuit product estimate.

| Rule | Other seed scope | Metric | Median cost gain | Comparisons with observed failures |
|:--|:--|:--|--:|--:|
| R03 | inverse_replay_cell, 256 bits | cell_static_Toffolis | 11.883% | 0/1 |
| R05 | point_addition, 256 bits | TQ | 0.224% | 0/1 |
| R07 | point_addition, 256 bits | TQ | 0.081% | 0/2 |

## Failure evidence

A raw cost reduction can accompany failures. Such a reduction supplies no eligible gain.

- R18, modular_division/16/TQ: 3/3 seed comparisons have observed failures.
- R19, modular_division/16/TQ: 3/3 seed comparisons have observed failures.
- R20, modular_division/16/TQ: 3/3 seed comparisons have observed failures.
