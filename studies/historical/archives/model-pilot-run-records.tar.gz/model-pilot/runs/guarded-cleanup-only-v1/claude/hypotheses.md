# Pre-run questions and predictions

Question: Does measured cleanup lower T while preserving the boundary map?
Hypothesis: Remove one Toffoli per unconditional temporary AND cleanup. Preserve Q under the same allocation.
Reason: The conditioned CZ removes the measurement sign.
Invariant: The temporary wire equals the AND of retained, unchanged controls.
Cheapest disproof: A phase, output, or scratch counterexample.
Acceptance: The controlled compiled pair matches the predicted delta and passes its declared independent test.

Question: Does model feedback improve discovery under matched proposal caps?
Hypothesis: Diagnostic repairs improve the gain curve or final independently tested reward.
Cheapest disproof: Repeated controls match or exceed those gains after recorded costs.
Acceptance: Describe the observed effect across all baselines and seeds. A null result is valid.

Question: Does the quick screen save work without losing useful candidates?
Hypothesis: The chosen fitting policy retains at least 90% of useful held-out candidates.
Cheapest disproof: Held-out false rejections or cascade overhead above direct long evaluation.

Question: Does a smaller model context improve token efficiency and search performance?
Hypothesis: Equivalent structural encodings lower reported tokens without losing useful edits or final gains.
Cheapest disproof: Token savings disappear in wrapper overhead, or proposal quality and circuit gains fall.

Keep observations separate from these predictions. Preserve failed hypotheses and consumed audits.
